xenon2 / created by Patrick H. Lauke aka redux / 10 Oct 2004 / http://www.splintered.co.uk
Incomplete set, based on the shop sequence of the Bitmap Brothers' Amiga shooter "Xenon 2 - Megablast"
Designed for aliased font size of 5 pixels (or multiples thereof).
You may freely use this font for any commercial or non-commercial projects. A small credit and/or link to my site would be appreciated.